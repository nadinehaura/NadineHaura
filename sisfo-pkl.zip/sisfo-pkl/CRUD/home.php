<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Halaman Konsultasi</title>
</head>
<body>
    <div class="chat-container">
        <h3>Selamat Datang di  Sistem Informasi PKL SMKN9 MEDAN </h3>
        <p>Sistem ini dirancang khusus untuk memfasilitasi komunikasi dan konsultasi 
            antara siswa yang sedang menjalani PKL dengan guru pembimbing di sekolah. Dengan adanya sistem ini, proses bimbingan dan pengawasan terhadap 
            pelaksanaan PKL dapat berjalan lebih efektif, efisien, dan terstruktur.
             -Fungsi Sistem Informasi PKL
            Media Konsultasi
            Siswa dapat menggunakan sistem ini untuk menyampaikan berbagai kendala, masalah, atau pertanyaan yang dihadapi selama menjalani PKL di tempat kerja. 
            Hal ini memungkinkan siswa untuk mendapatkan arahan langsung dari guru pembimbing tanpa harus datang secara fisik ke sekolah.
            Pembimbingan Terarah
            Guru pembimbing dapat memberikan bimbingan secara berkala melalui fitur konsultasi, memberikan feedback, dan memantau perkembangan siswa selama PKL. 
            Dengan demikian, siswa mendapatkan pengawasan yang optimal meskipun sedang berada di lokasi kerja.
            Dokumentasi dan Pelaporan
            Sistem ini juga menyediakan fasilitas bagi siswa untuk mengunggah laporan kegiatan harian atau mingguan selama PKL. Guru pembimbing dapat mengakses laporan
            tersebut sebagai bahan evaluasi dan penilaian.
            -Manfaat Sistem
            Mempermudah komunikasi antara siswa dan guru pembimbing tanpa batasan waktu dan tempat.
            Meningkatkan efektivitas bimbingan selama masa PKL.
            Membantu siswa dalam menyelesaikan masalah yang dihadapi di tempat kerja dengan cepat dan tepat.
            Mendukung pelaksanaan PKL yang lebih terorganisir dan terdokumentasi dengan baik.
            
            Pesan Penting
            Silakan manfaatkan sistem ini dengan sebaik-baiknya untuk mendukung keberhasilan Anda selama menjalani PKL. 
            Jangan ragu untuk mengajukan pertanyaan atau melaporkan kendala yang dihadapi. Guru pembimbing kami siap membantu dan memberikan solusi demi 
            kelancaran dan keberhasilan PKL Anda.</p>
</div>
</body>
</html>