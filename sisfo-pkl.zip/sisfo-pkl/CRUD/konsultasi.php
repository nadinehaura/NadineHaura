<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Halaman Konsultasi</title>
</head>
<body>
    <div class="chat-container">
        <h2>Konsultasi Chat</h2>
        <div class="chat-box" id="chatBox">
            <!-- Pesan Akan Muncul Disini -->
        </div>
        <input type="text" id="chatInput" class="chat-Input"
        placeholder="Tulis pesan...">
        <button onclick="sendMessage()">Kirim</button>
    </div>
    <script>
        function sendMessage(){
            const chatInput = document.getElementById('chatInput');
            const chatBox = document.getElementById('chatBox');
            const message = chatInput.value.trim();

            if(message){
                //tambahkan pesan pengguna ke checkBox
                const usermessage = document.createElement('div');
                userMessage.className = 'message user';
                userMessage.innerText = message;
                chatBox.appendChilf(userMessage);

                //simulasi balasan admin(bisa diganti dengan backend handling)
                const adminMessage = document.createElement('div');
                adminMessage.className = 'message admin';
                adminMessage.innerText = 'Mimin: Makasii yaaa, pesan kamu udah di terimaa nihh>,<';
                chatBox.appendChild(adminMessage);

                //scroll ke bagian bawah chat
                chatBox.scrollTop = chatBox.scrollHeight;

                //Bersihkan input
                chatInput.value='';
            }
        }
    </script>
</body>
</html>